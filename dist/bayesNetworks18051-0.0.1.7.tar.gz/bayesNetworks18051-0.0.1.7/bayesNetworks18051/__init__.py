from bayesNetworks18051.redes import BayesianNetwork
from bayesNetworks18051.redes import Node
