from bayesNetworks18051 import BayesianNetwork
from bayesNetworks18051 import Node
