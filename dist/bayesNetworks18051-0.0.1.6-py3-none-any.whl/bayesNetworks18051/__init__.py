from bayesNetworks18051.redes import *
